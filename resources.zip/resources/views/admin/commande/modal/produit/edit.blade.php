<div class="modal-header modal-header-primary">
    <h4 class="modal-title">Modifier produit {{$produit->name}}</h4>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <form action="{{route('commande.update', ['produit' => $produit->id])}}" role="form" id="form-modifier-produit" method="POST">
        @csrf
        <div class="card-body">
            <div class="form-group">
                <label for="name">Designation</label>
                <input type="text" name="name" class="form-control" id="name" placeholder="Designation" value="{{$produit->name}}" required>
            </div>
            <div class="form-group">
                <label for="quantite">Formule</label>
                <select class="form-control" name="" id="" disabled>
                    <option value="">{{$produit->formule->name}}</option>
                </select>
            </div>
            <div class="form-group">
                <label for="quantite">Quantité</label>
                <input type="number" name="quantite" class="form-control" id="quantite" placeholder="Quantité" value="{{$produit->quantite}}" required>
            </div>
            <div class="form-group">
                <label for="pu_vente">P.U</label>
                <input type="number" name="pu_vente" class="form-control" id="pu_vente" placeholder="Prix unitaire" value="{{$produit->pu_vente}}" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" placeholder="Description complète">{{$produit->description}}</textarea>
            </div>
        </div>
        <!-- /.card-body -->
    </form>
</div>
<div class="modal-footer justify-content-between">
    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
    <button type="submit" form="form-modifier-produit" class="btn btn-primary float-right">Sauvegarder</button>
</div>
