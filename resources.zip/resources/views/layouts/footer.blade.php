<footer class="main-footer">
    <strong>Copyright &copy; <script>document.write(new Date().getFullYear());</script> Tsaravidy.</strong>
    Tout droit reservé.
    <div class="float-right d-none d-sm-inline-block">
       <span>Designed by <b><strong>ISM</strong></b></span>
    </div>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
