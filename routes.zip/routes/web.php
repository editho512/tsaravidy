<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('accueil');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/dashboard', 'DashboardController@index')->name('dashboard');


/**-------------------DEPENSE CONTROLLER----------------------*/

Route::get('/depenses', 'DepenseController@index')->name('depense');

Route::post('/depense', 'DepenseController@create')->name('depense.create');

Route::get('/depense/{depense}', 'DepenseController@edit')->name('depense.edit');

Route::post('/depense/update/{depense}', 'DepenseController@update')->name('depense.update');

Route::get('/depense/supprimer/{depense}', 'DepenseController@showDelete')->name('depense.delete.show');

Route::delete('/depense/supprimer/{depense}', 'DepenseController@delete')->name('depense.delete');

/**-------------------FIN DEPENSE CONTROLLER----------------------*/


/**-------------------MATIERE CONTROLLER----------------------*/

Route::get('/matieres', 'MatierePremiereController@index')->name('matiere');

Route::get('/matiere/{matiere}', 'MatierePremiereController@show')->name('matiere.show');

Route::post('/matiere', 'MatierePremiereController@create')->name('matiere.create');

Route::get('/matiere/single/{matiere}', 'MatierePremiereController@editSingle')->name('matiere.edit');

Route::post('/matiere/single/update/{matiere}', 'MatierePremiereController@updateSingle')->name('matiere.update');

Route::get('/matiere/single/delete/{matiere}', 'MatierePremiereController@showDeleteSingle')->name('matiere.single.delete.show');

Route::delete('/matiere/single/delete/{matiere}', 'MatierePremiereController@deleteSingle')->name('matiere.single.delete');

Route::get('/matiere-premiere/{matierePremiere}', 'MatierePremiereController@edit')->name('matiere.premiere.edit');

Route::post('/matiere-premiere/update/{matierePremiere}', 'MatierePremiereController@update')->name('matiere.premiere.update');

Route::get('/matiere-premiere/supprimer/{matierePremiere}', 'MatierePremiereController@showDelete')->name('matiere.premiere.delete.show');

Route::delete('/matiere-premiere/supprimer/{matierePremiere}', 'MatierePremiereController@delete')->name('matiere.premiere.delete');

Route::get('/ajouter-matiere-premiere', 'MatierePremiereController@addSingleView')->name('add.single.matiere.view');

Route::post('/ajouter-matiere-premiere', 'MatierePremiereController@addSingle')->name('post.add.single.matiere');

/**-------------------FIN MATIERE CONTROLLER----------------------*/

/**-------------------FORMULE CONTROLLER----------------------*/

Route::get('/formules', 'FormuleController@index')->name('formule');

Route::get('/ajouter-formule', 'FormuleController@addSingleView')->name('add.single.formule.view');

Route::post('/ajouter-formule', 'FormuleController@addSingle')->name('post.add.single.formule');

Route::get('/formule/modifier/{formule}', 'FormuleController@editSingle')->name('formule.single.edit');

Route::post('/formule/modifier/{formule}', 'FormuleController@updateSingle')->name('formule.single.update');

Route::get('/formule/supprimer/{formule}', 'FormuleController@showDeleteSingle')->name('formule.single.delete.show');

Route::delete('/formule/supprimer/{formule}', 'FormuleController@deleteSingle')->name('formule.single.delete');

Route::get('/formule/{formule}', 'FormuleController@show')->name('formule.show');

Route::post('/formule/produit', 'FormuleController@create')->name('formule.create');

Route::get('/formule/produit/{formuleProduit}', 'FormuleController@edit')->name('formule.edit');

Route::post('/formule/produit/update/{formuleProduit}', 'FormuleController@update')->name('formule.update');

Route::delete('/formule/produit/delete/{formuleProduit}', 'FormuleController@destroy')->name('formule.destroy');

/**-------------------FIN FORMULE CONTROLLER----------------------*/


/**-------------------COMMANDE CONTROLLER----------------------*/

Route::get('/commandes', 'CommandeController@index')->name('commande');

Route::post('/ajouter-commande', 'CommandeController@addSingle')->name('post.add.single.commande');

Route::get('/commande/modifier/{commande}', 'CommandeController@editSingle')->name('commande.single.edit');

Route::post('/commande/modifier/{commande}', 'CommandeController@updateSingle')->name('commande.single.update');

Route::get('/commande/supprimer/{commande}', 'CommandeController@showDeleteSingle')->name('commande.single.delete.show');

Route::delete('/commande/supprimer/{commande}', 'CommandeController@deleteSingle')->name('commande.single.delete');

Route::get('/commande/{commande}', 'CommandeController@show')->name('commande.show');

Route::post('/commande/produit', 'CommandeController@create')->name('commande.create');

Route::get('/commande/produit/{produit}', 'CommandeController@edit')->name('commande.edit');

Route::post('/commande/produit/update/{produit}', 'CommandeController@update')->name('commande.update');

Route::get('/commande/produit/supprimer/{produit}', 'CommandeController@showDeleteProduit')->name('commande.produit.delete.show');

Route::delete('/commande/produit/supprimer/{produit}', 'CommandeController@deleteProduit')->name('commande.produit.delete');

/**------------------------------*/ //A EDITER

Route::get('/commande/produit/production/{produit}', 'CommandeController@showProduit')->name('commande.produit.show');

Route::post('/commande/produit/production', 'CommandeController@createProduit')->name('commande.produit.create');

Route::get('/commande/produit/modifier/production/{production}', 'CommandeController@editProduit')->name('commande.produit.edit');

Route::post('/commande/produit/production/update/{production}', 'CommandeController@updateProduit')->name('commande.produit.update');

Route::get('/commande/produit/supprimer/production/{production}', 'CommandeController@showDeleteProduction')->name('commande.production.delete.show');

Route::delete('/commande/produit/supprimer/production/{production}', 'CommandeController@deleteProduction')->name('commande.production.delete');

/**-------------------FIN COMMANDE CONTROLLER----------------------*/

/**------------------LIVRAISON CONTROLLER-------------------------*/

Route::post('/livraison', 'LivraisonController@create')->name('livraison.create');

Route::get('/livraison/modifier/{livraison}', 'LivraisonController@edit')->name('livraison.edit');

Route::post('/livraison/update/{livraison}', 'LivraisonController@update')->name('livraison.update');

Route::get('/livraison/supprimer/{livraison}', 'LivraisonController@showDelete')->name('livraison.delete.show');

Route::delete('/livraison/supprimer/{livraison}', 'LivraisonController@delete')->name('livraison.delete');

/**------------------FIN LIVRAISON CONTROLLER-------------------------*/

