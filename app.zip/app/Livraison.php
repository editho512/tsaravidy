<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Livraison extends Model
{

    protected $fillable = ['produit_id', 'numero_bl', 'quantite', 'date_livraison', 'commentaire'];

    protected $dates = ['date_livraison'];

    public function produit(){
        return $this->belongsTo(Produit::class);
    }
}
