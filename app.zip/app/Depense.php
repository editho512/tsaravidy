<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Depense extends Model
{
    protected $fillable = ['name', 'unite', 'numero_bl', 'type', 'fournisseur', 'quantite', 'pu', 'montant', 'frais_livraison', 'mode_paiement', 'montant_credit', 'date_credit', 'commentaire'];
    protected $dates = ['date_credit'];
}

