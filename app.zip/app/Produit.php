<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{

    protected $fillable = ['name', 'commande_id', 'category_id', 'formule_id', 'quantite', 'pu_vente', 'montant', 'description'];

    public function commande(){
        return $this->belongsTo(Commande::class);
    }

    public function formule(){
        return $this->belongsTo(Formule::class);
    }

    public function productions(){
        return $this->hasMany(Production::class);
    }

    public function livraisons(){
        return $this->hasMany(Livraison::class);
    }

    public function variations(){
        return $this->formule()->with('variations')->get()->pluck('variations')->flatten();
    }

    public function cycleTotal(){
        return $this->productions()->sum('nombre_cycle');
    }

    public function casseTotal(){
        return $this->productions()->sum('nombre_casse');
    }

    public function revientMoyen(){

        $revient = 0;

        $productions = $this->productions;

        foreach ($productions as $production){
            $revient += $production->quantite * $production->revient;
        }

        $revient = $revient / ($this->quantiteProduit() - $this->casseTotal());

        return round($revient, 2);
    }

    public function quantiteProduit(){
        return $this->productions()->sum('quantite');
    }

    public function quantiteLivrer(){
        return $this->livraisons()->sum('quantite');
    }

    public function coutTotalProduction(){
        return $this->quantite * $this->revientMoyen();
    }

    public function quantiteAProduire(){
        return $this->quantite - $this->quantiteProduit();
    }

    public function quantiteDisponible(){
        return $this->productions()->where('date_available', '<=', Carbon::now())->sum('quantite') - $this->quantiteLivrer();
    }

    public function quantiteEnSechage(){
        return $this->productions()->where('date_available', '>', Carbon::now())->sum('quantite');
    }

    public function isProductionComplete(){
        return $this->quantite == $this->quantiteProduit();
    }

    public static function boot() {
        parent::boot();

        static::deleting(function($produit) {
            $produit->productions()->delete();
            $produit->livraisons()->delete();
        });
    }

}
