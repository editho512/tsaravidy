<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Production extends Model
{

    protected $fillable = ['produit_id', 'nombre_cycle', 'quantite', 'nombre_casse', 'date_available', 'date_production', 'revient', 'commentaire'];

    protected $dates = ['date_available', 'date_production'];

    public function produit(){
        return $this->belongsTo(Produit::class);
    }

}
