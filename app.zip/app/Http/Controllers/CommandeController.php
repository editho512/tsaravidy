<?php

namespace App\Http\Controllers;

use App\Commande;
use App\Formule;
use App\Livraison;
use App\Production;
use App\Produit;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CommandeController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $commandes = Commande::all();

        $active_commande_index = 'active';

        /*alertify()->success('Updated record successfully')->delay(3000)->clickToClose()->position('bottom right');*/

        return view('admin.commande.commande', compact('active_commande_index', 'commandes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function create(Request $request)
    {
        $verb = $request->all();

        $verb['montant'] = $verb['quantite'] * $verb['pu_vente'];

        $produit = Produit::create($verb);

        $string = $produit->name.' ajouté avec succès.';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function createProduit(Request $request)
    {
        $verb = $request->all();

        $verb['date_production'] = Carbon::createFromFormat('d/m/Y', $verb['date_production'])->format('Y-m-d');
        $verb['date_available'] = Carbon::parse($verb['date_production'])->addHours($verb['date_available'])->toDateTimeString();

        $produit = Produit::find($verb['produit_id']);

        $matieres_besoins = $produit->variations();

        foreach ($matieres_besoins as $matiere){
            $matiere->besoin = $matiere->valeur * $verb['nombre_cycle'];
            $matiere->dispo = $matiere->matiere->stockDisponible();
        }

        $matiere_indisponiles = $matieres_besoins->filter(function ($value, $key) {
            return $value->dispo < $value->besoin;
        })->flatten();

        if (!$matiere_indisponiles->isEmpty()){
            foreach ($matiere_indisponiles as $indisponile){
                alertify()->error("Stock de ".$indisponile->matiere->name." insuffisant.")->persistent()->clickToClose()->position('bottom right');
            }
            return redirect()->back();
        }

        $revient = 0;

        foreach ($matieres_besoins as $matiere){
            $matiere->matiere->reduceStock($matiere->besoin);
            //Calcul du revient
            $revient += $matiere->valeur * $matiere->matiere->prixCourant();
        }

        $verb['revient'] = round(($revient * $verb['nombre_cycle'])/$verb['quantite'], 2);

        //dd($verb['revient']);

        $production = Production::create($verb);

        $string = $produit->name.' ajouté avec succès.';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Add single ressource in storage.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addSingle(Request $request)
    {
        $verb = $request->all();

        $verb['numero_bc'] = strtoupper($verb['numero_bc']);

        $verb['date_livraison'] = Carbon::createFromFormat('d/m/Y', $verb['date_livraison'])->format('Y-m-d');
        $verb['date_paiement'] = Carbon::createFromFormat('d/m/Y', $verb['date_paiement'])->format('Y-m-d');

        $commande = Commande::create($verb);

        $string = 'Commande '.$commande->numero_bc.' ajouté avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Commande  $commande
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function show(Commande $commande)
    {
        $active_commande_index = 'active';

        if (!$commande){
            abort(404);
        }

        $produits = $commande->produits;

        $formules = Formule::whereHas('variations')->get();

        //return response()->json($produits[0]->variations());

        return view('admin.commande.produit', compact('active_commande_index', 'commande', 'produits', 'formules'));

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Produit  $produit
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showProduit(Produit $produit)
    {
        $active_commande_index = 'active';

        if (!$produit){
            abort(404);
        }

        $productions = $produit->productions;

        $variations = $produit->variations();

        $formule = $produit->formule;

        $commande = $produit->commande;

        $reste = $produit->quantite - $produit->quantiteProduit();

        $livraisons = $produit->livraisons;

        return view('admin.commande.production', compact('active_commande_index', 'commande', 'produit', 'formule', 'productions', 'variations', 'reste', 'livraisons'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Commande  $commande
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function editSingle(Commande $commande)
    {
        return view('admin.commande.modal.commande.edit', compact('commande'));
    }

    /**
     * Show the form for deleting the specified resource.
     *
     * @param  \App\Commande  $commande
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showDeleteSingle(Commande $commande)
    {
        return view('admin.commande.modal.commande.delete', compact('commande'));
    }

    /**
     * Deleting the specified resource.
     *
     * @param  \App\Commande  $commande
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteSingle(Commande $commande)
    {
        $numeroBC = $commande->numero_bc;

        $produits = $commande->produits;

        foreach ($produits as $produit) {

            $productions = $produit->productions;

            $matieres_besoins = $produit->variations();

            foreach ($productions as $production){
                foreach ($matieres_besoins as $matiere){
                    $matiere->besoin = $matiere->valeur * $production->nombre_cycle;
                    $matiere->matiere->recoverStock($matiere->besoin);
                }
            }

        }

        $commande->delete();

        $string = 'Commande BC n° '.$numeroBC.' supprimée avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Produit  $produit
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function edit(Produit $produit)
    {
        return view('admin.commande.modal.produit.edit', compact('produit'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Production  $production
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function editProduit(Production $production)
    {
        return view('admin.commande.modal.production.edit', compact('production'));
    }

    /**
     * Show the form for deleting the specified resource.
     *
     * @param  \App\Produit  $produit
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showDeleteProduit(Produit $produit)
    {
        return view('admin.commande.modal.produit.delete', compact('produit'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Production  $production
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showDeleteProduction(Production $production)
    {
        return view('admin.commande.modal.production.delete', compact('production'));
    }

    /**
     * Deleting the specified resource.
     *
     * @param  \App\Produit  $produit
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteProduit(Produit $produit){

        $name = $produit->name;

        $productions = $produit->productions;

        $matieres_besoins = $produit->variations();

        foreach ($productions as $production){
            foreach ($matieres_besoins as $matiere){
                $matiere->besoin = $matiere->valeur * $production->nombre_cycle;
                $matiere->matiere->recoverStock($matiere->besoin);
            }
        }

        $produit->delete();

        $string = 'Produit '.$name.' supprimée avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Deleting the specified resource.
     *
     * @param  \App\Production  $production
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deleteProduction(Production $production){

        $name = $production->produit->name;
        $nombre = $production->quantite;

        $matieres_besoins = $production->produit->variations();

        foreach ($matieres_besoins as $matiere){
            $matiere->besoin = $matiere->valeur * $production->nombre_cycle;
            $matiere->matiere->recoverStock($matiere->besoin);
        }

        $production->delete();

        $string = $nombre.' '.$name.' supprimée avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Commande  $commande
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateSingle(Request $request, Commande $commande)
    {
        $verb = $request->all();

        $verb['date_livraison'] = Carbon::createFromFormat('d/m/Y', $verb['date_livraison'])->format('Y-m-d');
        $verb['date_paiement'] = Carbon::createFromFormat('d/m/Y', $verb['date_paiement'])->format('Y-m-d');

        $commande->update($verb);

        $string = 'Mis à jour avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Produit  $produit
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Produit $produit)
    {
        $verb = $request->all();

        $verb['montant'] = $verb['quantite'] * $verb['pu_vente'];

        $produit->update($verb);

        $string = 'Mis à jour avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Production  $production
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateProduit(Request $request, Production $production)
    {
        $verb = $request->all();

        $verb['date_production'] = Carbon::createFromFormat('d/m/Y', $verb['date_production'])->format('Y-m-d');
        $verb['date_available'] = Carbon::parse($verb['date_production'])->addHours($verb['date_available'])->toDateTimeString();

        $verb['revient'] = round(($production->revient * $production->quantite) / $verb['quantite'], 2);

        //dd($production->revient, $verb['quantite'], $production->quantite, $verb['revient']);

        $production->update($verb);

        $string = 'Mis à jour avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Commande  $commande
     * @return \Illuminate\Http\Response
     */
    public function destroy(Commande $commande)
    {
        //
    }
}
