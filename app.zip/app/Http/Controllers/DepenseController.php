<?php

namespace App\Http\Controllers;

use App\Depense;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DepenseController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application depense.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $depenses = Depense::all();

        $types = ['Charge salariale mensuelle', 'Charge locative', 'Charge de maintenance machine',
            'Dépenses divers', 'Agios', 'Carburant par semaine'];

        $active_depense_index = 'active';
        return view('admin.depense.depense', compact('active_depense_index', 'depenses', 'types'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function create(Request $request)
    {
        $verb = $request->all();

        $verb['montant'] = ($verb['quantite'] * $verb['pu']) + $verb['frais_livraison'];

        $verb['numero_bl'] = strtoupper($verb['numero_bl']);

        if ($verb['mode_paiement'] == 'credit'){

            $verb['montant'] = $verb['montant'] + $verb['montant_credit'];

            $verb['date_credit'] = Carbon::createFromFormat('d/m/Y', $verb['date_credit'])->format('Y-m-d');
        }

        Depense::create($verb);

        return redirect()->route('depense');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Depense  $depense
     * @return \Illuminate\Http\Response
     */
    public function show(Depense $depense)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Depense  $depense
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function edit(Depense $depense)
    {
        $types = ['Charge salariale mensuelle', 'Charge locative', 'Charge de maintenance machine',
            'Dépenses divers', 'Agios', 'Carburant par semaine'];
        return view('admin.depense.modal.edit', compact('depense', 'types'));
    }

    /**
     * Show the form for deleting the specified resource.
     *
     * @param \App\Depense  $depense
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showDelete(Depense $depense)
    {
        return view('admin.depense.modal.delete', compact('depense'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Depense  $depense
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Depense $depense)
    {

        //dd($depense, $request);
        $verb = $request->all();

        $verb['montant'] = ($verb['quantite'] * $verb['pu']) + $verb['frais_livraison'];

        if ($verb['mode_paiement'] == 'credit'){

            $verb['montant'] = $verb['montant'] + $verb['montant_credit'];

            $verb['date_credit'] = Carbon::createFromFormat('d/m/Y', $verb['date_credit'])->format('Y-m-d');

        }else{

            $verb['montant_credit'] = 0;
            $verb['date_credit'] = null;

        }

        $depense->update($verb);

        return redirect()->route('depense');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Depense  $depense
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Depense $depense)
    {

        $name = $depense->name;

        $depense->delete();

        $string = 'Depense '.$name.' supprimé avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Depense  $depense
     * @return \Illuminate\Http\Response
     */
    public function destroy(Depense $depense)
    {
        //
    }
}
