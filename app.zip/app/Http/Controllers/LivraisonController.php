<?php

namespace App\Http\Controllers;

use App\Livraison;
use App\Produit;
use Carbon\Carbon;
use Illuminate\Http\Request;

class LivraisonController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function create(Request $request)
    {
        $verb = $request->all();

        $produit = Produit::find($request->produit_id);

        if ($request->quantite > $produit->quantiteDisponible()){
            $string = 'Erreur, la quantité doit être inférieur ou égale à '.$produit->quantiteDisponible();
            alertify()->error($string)->delay(5000)->clickToClose()->position('bottom right');
            return redirect()->back();
        }

        $verb['date_livraison'] = Carbon::createFromFormat('d/m/Y', $verb['date_livraison'])->format('Y-m-d');

        $livraison = Livraison::create($verb);

        $string = 'Livraison n° '.$livraison->numero_bl.' ajouté avec succès.';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Livraison  $livraison
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function edit(Livraison $livraison)
    {
        $produit = Produit::find($livraison->produit_id);
        return view('admin.commande.modal.livraison.edit', compact('livraison', 'produit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Livraison  $livraison
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Livraison $livraison)
    {
        $verb = $request->all();

        $produit = Produit::find($livraison->produit_id);

        if ($request->quantite > ($produit->quantiteDisponible()+$livraison->quantite)){
            $string = 'Erreur, la quantité doit être inférieur ou égale à '.($produit->quantiteDisponible()+$livraison->quantite);
            alertify()->error($string)->delay(5000)->clickToClose()->position('bottom right');
            return redirect()->back();
        }

        $verb['date_livraison'] = Carbon::createFromFormat('d/m/Y', $verb['date_livraison'])->format('Y-m-d');

        $livraison->update($verb);

        $string = 'Mis à jour avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }

    /**
     * Show the form for deleting the specified resource.
     *
     * @param  \App\Livraison  $livraison
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function showDelete(Livraison $livraison)
    {
        $produit = Produit::find($livraison->produit_id);
        return view('admin.commande.modal.livraison.delete', compact('livraison', 'produit'));
    }

    /**
     * Deleting the specified resource.
     *
     * @param  \App\Livraison $livraison
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Livraison $livraison){

        $numero_bl = $livraison->numero_bl;

        $livraison->delete();

        $string = 'Livraison n° '.$numero_bl.' supprimée avec succès';

        alertify()->success($string)->delay(5000)->clickToClose()->position('bottom right');

        return redirect()->back();
    }
}
