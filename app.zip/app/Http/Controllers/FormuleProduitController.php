<?php

namespace App\Http\Controllers;

use App\FormuleProduit;
use Illuminate\Http\Request;

class FormuleProduitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FormuleProduit  $formuleProduit
     * @return \Illuminate\Http\Response
     */
    public function show(FormuleProduit $formuleProduit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FormuleProduit  $formuleProduit
     * @return \Illuminate\Http\Response
     */
    public function edit(FormuleProduit $formuleProduit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FormuleProduit  $formuleProduit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FormuleProduit $formuleProduit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FormuleProduit  $formuleProduit
     * @return \Illuminate\Http\Response
     */
    public function destroy(FormuleProduit $formuleProduit)
    {
        //
    }
}
